# The Wedding Circle — Landing Page Reorganization + Leaderboard Header

Implement both changes below as one carefully scoped landing-page update. Use the latest provided screenshots as visual references.

## 1. Inspect Before Changing Anything

First inspect the existing landing-page components, routing, wedding-card rendering, authentication, access-code flows, sample-wedding editing, leaderboard calculations, Developer section, header Feed button and three-dot menu.

Make the smallest targeted changes possible. Reuse existing components, routes and handlers. Do not rebuild the landing page from scratch.

Preserve all existing wedding data, user accounts, memberships, permissions, backend integrations, navigation, persistent state and working functionality. Do not reset or delete any data.

## 2. Preserve Existing Wedding Cards

- Keep the existing wedding cards, artwork, colours, typography, proportions, rounded corners and visual identity.
- Preserve the Chat and Live shortcuts on each card, including their existing actions.
- Preserve wedding names, dates, locations and other details.
- Preserve the existing “Pin as Landing Page” functionality and behaviour.
- Maintain responsive sizing so the cards remain attractive on mobile.
- Do not redesign the wedding cards.

## 3. Reorganize the Main Landing-Page Actions

Keep the existing wedding cards at the top as the main visual focus.

### A. Create a wedding
Place the existing **Create New Wedding** action immediately below the wedding-card area.

- Keep it as the primary burgundy button.
- Give it comfortable spacing and clear visual hierarchy.
- Reuse the existing wedding-creation route and handler.
- Do not change the wedding-creation process or its fields.

### B. Join a wedding
Create a visually unified section titled **Join a Wedding** with a short subtitle such as “Already invited? Enter your access code.”

Place the existing **Enter as Family** and **Enter as Guest** buttons together inside this section, using two balanced buttons on mobile where space permits.

- Preserve their existing entry flows, access-code handling, authentication requirements and permission checks.
- Do not combine their underlying logic or change the roles they grant.
- Maintain clear contrast between primary and secondary buttons.

## 4. Relocate Edit Sample Wedding

Remove the standalone **Edit sample wedding** action from the main landing-page content.

Move it into the existing three-dot menu or the appropriate existing Developer section, depending on its current implementation and permissions.

- Reuse the existing edit action.
- Preserve access restrictions and behaviour.
- Do not create a duplicate editing feature.
- Do not expose developer-only functionality to unauthorised users.
- If moving it safely requires changing access permissions, stop and report the issue rather than weakening those permissions.

## 5. Add a Subtle Discover Entry

Add a compact, elegant row titled **Discover** below the Create/Join actions and above the popular-weddings section.

Subtitle: “Wedding inspiration, products and professionals.”

Use a restrained compass/discovery icon, existing theme colours and a right chevron.

- Make the row open a separate Discover destination only if a valid destination already exists.
- If Discover is not implemented yet, create only the entry point with a clear placeholder state; do not fabricate marketplace content or a working destination.
- Keep this row visually secondary to creating or joining a wedding.
- Do not place product grids, advertisements or shopping banners directly on the landing page.
- Do not change the private wedding Home, Chat, Live, Album or More screens.
- Do not add a sixth bottom-navigation item.

## 6. Reorganize the Leaderboard Area

Preserve the existing Leaderboard and its scoring system.

Introduce a section heading such as **Popular Wedding Circles**, with a short subtitle explaining that featured weddings are ranked by activity.

Keep the existing leaderboard content and ranking presentation below it, with improved spacing and consistent card styling.

Do not change:
- Score weights for text, pictures, long videos or live viewers.
- Ranking calculations, ordering, tie handling or stored scores.
- Crown indicators, cover images, wedding identities or existing leaderboard functionality.

Do not invent popularity data or display fake rankings. If the current Leaderboard heading is needed to identify the ranking itself, retain it as a smaller subheading within this section.

## 7. Replace the Header Feed Button with Leaderboard

Modify the existing landing-page header using the screenshot as the visual reference.

- Remove the standalone **Feed** pill button from the top-right of the landing-page header.
- Replace it with a **Leaderboard** pill button in exactly the same position.
- Make the new button open the existing Leaderboard section or screen, reusing its current route, component and navigation handler wherever possible.
- Preserve existing Leaderboard rankings, scoring calculations, crown indicators, wedding cards and data. Do not create a duplicate leaderboard.
- Keep the existing three-dot menu at the far right, unchanged in appearance, position and functionality.
- Preserve the app logo, “The Wedding Circle” title, header spacing, typography, blush background, responsive layout and theme support.
- Ensure “Leaderboard” fits comfortably on narrow mobile screens. Adjust only the pill's internal spacing or width if necessary; do not overlap the app title or three-dot menu.
- Remove only the standalone header Feed button. Do not delete the Feed feature, its route, wedding-specific Feed functionality or associated data.
- If the Feed button has a notification dot, do not transfer it to Leaderboard unless it represents a genuine, implemented Leaderboard notification.
- Do not add a second Leaderboard button in the header.

## 8. Visual Design and Responsive Behaviour

Maintain The Wedding Circle's existing premium editorial wedding aesthetic:
- Blush, ivory, burgundy and restrained gold accents.
- Existing typography and theme tokens.
- Rounded cards and subtle borders.
- Clear spacing between major sections.
- Consistent button heights and alignment.
- Support for existing light and dark modes.
- Comfortable touch targets and no horizontal overflow.

Avoid excessive decoration, oversized empty gaps, redundant dividers and unnecessary animations. The landing page should feel like a cohesive wedding app, not an administrative dashboard or shopping marketplace.

## 9. Preserve Existing Navigation and State

- Preserve sign-in/sign-up, profile access, the three-dot menu and existing Developer controls.
- Preserve wedding-card selection and pinned-wedding state.
- Do not change backend schemas or stored data for this visual reorganization.
- Do not duplicate buttons, routes, components or ranking systems.
- Preserve the Feed feature and its existing access points elsewhere in the app.
- Preserve the existing bottom-navigation destinations; do not add a sixth item or remove/rename any destination.
- Do not alter authentication, role permissions, memberships or access-code behaviour.

## 10. Testing and Acceptance Criteria

After implementation, verify:

1. Existing wedding cards and their Chat/Live shortcuts still work.
2. Create New Wedding opens the existing creation flow.
3. Family and Guest buttons preserve their distinct entry and permission flows.
4. Edit Sample Wedding remains available to the same authorised users.
5. Discover does not open a broken route or display fabricated content.
6. Leaderboard scores, ordering and existing data remain unchanged.
7. The header displays **Leaderboard** instead of Feed.
8. Tapping the header Leaderboard button opens the existing Leaderboard successfully.
9. The three-dot menu remains unchanged and functional.
10. The Feed remains accessible through its existing supported locations.
11. The Leaderboard label fits on narrow mobile screens without overlapping the title, logo or menu.
12. The page has no clipping, excessive gaps or horizontal scrolling on narrow screens.
13. Existing light/dark themes use active theme tokens.
14. Relevant tests, type checks and build checks are run where available, and regressions caused by these changes are fixed.

Do not claim that a route, build or test works unless it has actually been verified.

## Final Report

Report:
- Files changed.
- Sections reorganized.
- Exact header and navigation changes.
- Whether the existing Leaderboard navigation was reused.
- Functionality verified.
- Checks actually run and their results.
- Any unresolved issues or additional manual configuration required.

Implement only this combined landing-page reorganization and Feed-to-Leaderboard header replacement. Do not make unrelated UI, backend, database, permission or feature changes.
