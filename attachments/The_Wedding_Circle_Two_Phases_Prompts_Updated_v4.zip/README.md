# The Wedding Circle — Two-Phase Prompt Pack

Run the phases in order, one at a time in Grok.

1. **Phase 1 — Landing Page Reorganization and Leaderboard Header:** reorganizes the landing page and replaces the header Feed button with Leaderboard.
2. **Phase 2 — Global Animations and Glass UI:** after Phase 1 is complete and tested, adds iPhone-inspired transitions and consistent glass surfaces across the app and all existing themes.

Both prompts include inspection-first instructions, preservation safeguards, acceptance checks and a final report requirement.

Phase 2 also includes the correction for the Chat filter UI: an integrated top-bar dropdown drawer instead of a detached Filter button below the bar.

Phase 2 also removes Download from voice-note messages only and moves the three circled utility actions into the existing + composer menu, preserving their current handlers.

Phase 2 specifies that saved YouTube Live links should play inline automatically when the user enters the Live page, with full-screen and landscape viewing controls and an external fallback only when inline playback is unavailable.
