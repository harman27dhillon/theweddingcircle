# The Wedding Circle — Phase 2: Global iPhone-Like Animations and Glass UI

Run this phase only after Phase 1 is complete and tested. Use the existing app and screenshots as references. Add consistent, polished page transitions and a glass-like surface treatment throughout The Wedding Circle, including inside weddings and after any theme is applied.

## 1. Inspect before changing anything
Inspect app architecture, routes/page transitions, shared UI components, theme system/tokens, wedding cards, in-wedding screens, popups, menus, dialogs and existing animations. Identify shared components/styles so the changes can be consistent instead of patched screen by screen. Make incremental targeted changes; do not rebuild the app or replace the theme system.

## 2. iPhone-like transitions across the app
Add smooth, restrained, iPhone-inspired transitions where appropriate across:
- Landing page and wedding selection.
- Wedding Home.
- Chat and chat media viewer.
- Live screen and live-stream viewing.
- Album and photo/video viewer.
- More and Host Control.
- Existing menus, popovers, drawers and non-destructive windows.
- Existing create/join wedding flows and other supported screens.

Use subtle horizontal slides, fades, small scale transitions and natural easing. Keep transitions quick and consistent; avoid excessive bounce, dramatic zooms or delays. Preserve swipe gestures, chat scrolling, album swipes, live controls, camera gestures, form interaction and browser back navigation. Prefer shared transition utilities over independent animations on every element.

## 3. Glass-like wedding cards
Give wedding cards a refined glass appearance using appropriate translucent surfaces/overlays, background blur where supported, subtle borders, restrained highlights, soft shadows and theme-aware tinting. Maintain text contrast. Preserve wedding artwork, names, dates, locations, Chat/Live buttons, proportions, pinning and all card actions. Do not regenerate or replace existing card art.

## 4. Glass-like surfaces throughout the app
Apply the same design language to appropriate existing surfaces:
- In-wedding panels and cards.
- Header/navigation surfaces where visually appropriate.
- Popups, menus, drawers and floating windows.
- Host Control panels and settings windows.
- Chat media preview containers and suitable secondary panels.

Not every element should be translucent. Text-entry fields, critical warnings and dense content may need more opaque surfaces for legibility. Preserve layouts and interactions.

## 5. Glass must persist across all themes
The glass treatment must remain when users change wedding themes. Use shared design tokens or reusable surface styles. Themes may change glass tint, accent colour, border tone, highlights and text contrast, but must not remove the glass effect. Support all existing themes and light/dark variants. Do not hardcode one theme's colours, rename/delete/merge/reset themes or replace existing definitions. Preserve saved theme preferences and customisation options. Test contrasting light, dark and strongly coloured themes.


## 6. Correct the Chat Filter UI: Use a Top-Bar Dropdown Drawer

The supplied screenshot shows the current incorrect implementation: a standalone **Filter** pill/button below the top information bar, with a large empty gap before the posts. The intended design is a compact dropdown drawer anchored directly to the existing top information bar.

Replace the current misplaced Filter button and its detached/drop-arrow-style control with the following behaviour:

- Put a small, clearly aligned dropdown trigger inside the existing top information bar, using the current header layout and theme.
- Tapping the trigger opens a compact drawer/dropdown directly beneath the top information bar, visually attached to it.
- The drawer contains the existing filter options and any already-supported controls. Reuse the current filter logic; do not invent new filters.
- Tapping the trigger again, choosing an option, or tapping outside the drawer closes it. Taps inside the drawer must work normally.
- The drawer must overlay the content below it rather than reserving a tall blank area or pushing posts far down the page.
- Keep the drawer anchored to the bar during scrolling and responsive to mobile safe areas. Prevent clipping off-screen.
- Use the shared glass treatment requested in this phase, with theme-aware tint, subtle border and shadow, and readable text.
- Do not create a separate large floating Filter button below the header.
- Do not leave an extra arrow/trigger hanging underneath the top bar.
- Preserve all existing filter options, filtering behaviour, chat/feed data, posting, download, permissions and navigation. This is a UI placement and interaction correction only.
- Do not accidentally trigger controls underneath when dismissing the drawer by tapping outside.

### Filter drawer acceptance checks
1. No standalone Filter pill remains below the top bar.
2. The dropdown trigger is integrated into the top information bar.
3. The drawer opens directly beneath the bar and closes correctly.
4. Opening it does not create a large empty vertical gap or push content down.
5. All existing filter options work and the active theme styles the drawer correctly.
6. The drawer remains usable on narrow mobile screens and does not cover critical navigation controls.


## 7. Chat Composer Cleanup: Voice Notes and Utility Buttons

Use the latest supplied screenshot with red circles as the reference for the exact controls.

### A. Remove Download from voice-note messages
- Remove the **Download** action/link from voice-note/audio-message cards only.
- Keep voice-note playback, play/pause, progress/seek control, duration display and the existing voice-note message layout.
- Do not remove Download from photo or video messages; this instruction applies only to voice notes/audio messages.
- Do not delete voice-note files, change storage, alter message data or break audio playback.
- If the same shared component renders both audio and other media, conditionally hide Download only for audio/voice-note message types.

### B. Move the circled utility buttons into the existing plus menu
In the screenshot, the two circular utility buttons to the left of the message composer and the information button on the right are standalone controls above the composer. Remove these standalone placements and move their existing actions into the current **+** composer menu, alongside the camera and upload options that already exist there.

- Identify the exact actions currently bound to the two left-side buttons and the right-side information button before editing. Preserve their current meanings and handlers; do not guess or substitute actions.
- Add these actions as clearly labelled menu items in the existing plus menu, with suitable icons consistent with the app.
- Keep the existing camera and upload options in the plus menu.
- Do not create a second plus menu or duplicate any of these controls elsewhere.
- Preserve all existing permissions, availability rules, event handlers and behaviour of each action.
- Remove only the standalone button placements shown in the screenshot.
- Keep the message composer, microphone, Post button, text input, bottom navigation and safe-area spacing intact.
- Ensure the plus menu opens and closes correctly, fits on small screens, and does not cover the keyboard or become clipped. Tapping outside should dismiss the menu without accidentally activating controls underneath.
- If the exact action or permission for any circled button cannot be established from the current code, do not guess; report it and leave that action unchanged until it can be safely identified.

### Chat composer acceptance checks
1. Voice-note cards no longer show Download, while playback and duration/progress controls still work.
2. Photo/video Download actions remain unchanged.
3. The two left-side utility actions and right-side information action are accessible from the existing plus menu.
4. Their standalone circular buttons are no longer displayed above the composer.
5. Camera and upload remain available in the same plus menu.
6. The composer, microphone, Post button and bottom navigation remain functional and correctly positioned.
7. No duplicate actions, broken handlers, permission changes or data changes are introduced.

## 8. Performance, accessibility and compatibility
Keep animations lightweight and avoid unnecessary re-rendering. Avoid expensive full-screen blur or nested backdrop filters on low-powered devices. Use theme-matched solid/semi-opaque fallbacks when blur is unsupported or too expensive. Do not block input during animations. Respect reduced-motion preferences. Maintain accessible contrast, focus/tap states, touch usability and mobile layouts. Do not cause camera capture, media uploads, chat scrolling or live playback to stutter. Preserve safe-area and bottom-navigation behaviour unless correcting a verified defect.

## 9. Preserve functionality and data
Do not change wedding creation/joining, authentication, access codes, roles, permissions, memberships, wedding data, chat history, media, albums, settings, live-stream start/stop logic or current single-stream behaviour, camera/upload logic, theme definitions, routes, bottom navigation or backend schemas. Do not reset storage or user state. Do not remove tests or disable checks.

## 10. Acceptance checks
Verify transitions across main pages and in-wedding screens; existing gestures and browser back; wedding card content/artwork/actions; glass treatment on relevant panels; glass persistence across several themes including light/dark; readable text and controls; menus/windows; responsive chat, album, camera, upload and live playback; reduced-motion and blur fallbacks; no clipping, overflow or major performance regression. Run available tests, type checks and build checks. Report only checks actually performed.

## Final report
List files/shared components changed, pages/surfaces updated, themes/devices tested, checks actually run, results and unresolved issues. Implement only the global animation and glass-UI update in this phase; do not make unrelated feature, backend, database, permission or navigation changes.

## 10. YouTube Live: Automatically Playing Inline on the Live Page

Use the latest supplied Live-screen screenshot and the user's clarification as the exact requirement. The current YouTube Live card already embeds/plays the attached stream inside an expanded window after a user taps **Open**. The problem is that viewers must take that extra step. Do not interpret this as a request to send users to the YouTube app or website.

### Required behaviour
- When a valid, supported YouTube Live URL has been attached and saved for the wedding, automatically render the embedded player directly in the existing YouTube Live card/section as soon as a user navigates to the app's **Live** page.
- The live video should be visible and ready to play immediately in the normal in-app Live page layout, without requiring the viewer to press the current **Open** button first.
- Where the browser and YouTube player permit autoplay, start playback automatically in the inline player. Respect browser policies: if autoplay with sound is blocked, use the supported muted-autoplay or inline-ready behaviour, and provide an obvious in-player Play/unmute control. Never attempt to bypass autoplay restrictions.
- Do not require the viewer to open a separate YouTube page or external app just to see the stream.
- Keep the existing attached URL and Attach workflow for hosts/admins. Reuse the stored URL and current embed/player component; do not make users reattach the link or create a duplicate player.
- Provide clear controls for the viewer to **open the video full-screen** and **switch to landscape viewing** when supported by the browser/device. Full-screen should use the existing embedded player/browser-supported fullscreen capability. Landscape should use the appropriate supported screen-orientation API where available; if orientation locking is unsupported or denied, offer a clear manual rotate-device fallback without breaking playback.
- On returning from full-screen/landscape to the normal Live page, preserve the stream and return to the existing layout smoothly.
- Keep the app's own wedding-camera stream separate from YouTube Live. Do not combine their stream states, controls, comments, access permissions or start/stop logic.
- Keep the existing **Open on YouTube** fallback only for cases where the embedded player genuinely cannot play the link, such as unsupported, private, unavailable, ended or embedding-restricted content. It must not be the primary way to start viewing a valid embedded stream.
- Validate supported YouTube URL formats, including standard watch URLs, youtu.be links and supported live URLs. Use YouTube's supported embed/player mechanism; do not scrape pages, bypass restrictions or falsely claim a stream is live when that cannot be reliably established.
- Keep the player responsive and correctly proportioned on mobile. Do not allow horizontal overflow.
- Apply the existing theme/glass treatment to the player container, but never place translucent overlays over the actual video controls.
- Preserve existing Live-page comments, wedding camera controls, permissions, bottom navigation and other functionality.

### YouTube Live acceptance checks
1. With a valid saved embeddable YouTube Live URL, navigating to the Live page shows the embedded player immediately without tapping **Open**.
2. Playback starts automatically where supported; otherwise an obvious in-player Play control is available and browser restrictions are respected.
3. The viewer can enter full-screen using the player/browser-supported control.
4. Landscape viewing works where the browser/device supports orientation control, with a clear fallback if not supported.
5. Returning to the normal page preserves the stream and layout.
6. The external Open-on-YouTube fallback appears only when inline playback is genuinely unavailable.
7. The wedding's own camera stream remains separate and unaffected.
8. Existing URL attachment, comments, permissions, themes and mobile layout continue to work.
